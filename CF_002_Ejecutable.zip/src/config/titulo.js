module.exports = 'Caracterización de condiciones sanitarias de establecimientos'
