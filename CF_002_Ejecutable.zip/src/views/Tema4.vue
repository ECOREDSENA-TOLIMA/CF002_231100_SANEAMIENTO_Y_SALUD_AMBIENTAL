<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .titulo-principal.color-acento-contenido
      .titulo-principal__numero
        span 4
      h1 Reporte concepto sanitario

    .row.align-items-center.my-3.col-lg-12.mb-4             
      .col-6.p-4(style="background:#E7FFD1")
        p.mb-2.py-4(style="overflow-x: hidden !important") El reporte sanitario es una constancia de que el establecimiento se ha verificado de acuerdo con la normativa vigente, esta verificación es de manera presencial y técnica, ya que se debe recibir el visto bueno por parte de las personas encargadas de la visita para así garantizar las condiciones sanitarias y de salubridad del establecimiento de comercio.

      .col-6
        figure
          img(src='@/assets/curso/temas/4/1.png').m-auto(data-aos="fade-right") 

    .cont_4_1.pt-3(style="position:relative;")
      .titulo-segundo.color-acento-contenido(style="position:relative")
        h2#t_4_1  4.1 Tipos de leyes de salud pública enfocadas en riesgo sanitario 
      
    p Actualmente se encuentran vigentes varias leyes y decretos que permiten minimizar a nivel nacional el riesgo sanitario en los diferentes actores que se involucran, gracias a esto existe una política de salud pública la cual nos garantiza óptimas condiciones en los diferentes establecimientos. 

    p Las leyes, decretos o normas son las siguientes:

    .row.justify-content-center.mb-5(data-aos="fade-right")
      .col-lg-10  
        .row.align-items-center.my-5.col-lg-12.m-auto  
          .col-sm-12.col-lg-12
            .titulo-sexto.mb-0.color-acento-contenido.mb-1
              p.mb-0 #[b Tabla 3.] 
                i  Normas sanitarias
        .tabla-b.color-acento-contenido( alt='En la tabla 3 se muestran las normas sanitarias con su respectiva descripción.')
          table
            thead
              tr
              th(style="background-color:#FFAE7E") Norma
              th(style="background-color:#FFAE7E") Descripción
             
            tbody    
            tr
              td Ley 9 de 1979 
              td Código Sanitario.
            tr
              td Ley 715 de 2001    
              td Competencias.
            tr
              td Decreto 1500 de 2007
              td Se establece el reglamento técnico a través del cual se crea el Sistema Oficial de Inspección, Vigilancia y Control de la Carne, Productos Cárnicos Comestibles y Derivados Cárnicos.
            tr
              td Resolución 604 de 1993
              td Expendio de alimentos en vía pública.
            tr
              td Resolución 5109 de 2005
              td Rotulado y etiquetado.
            tr
              td Decreto. 1880 de 2011  
              td Venta de leche cruda.
            tr
              td Resolución. 1229 de 2013
              td Nuevo modelo de I.V.C. basado en riesgos – INVIMA.
            tr
              td Circular 046 de 2014 
              td Lineamientos para la articulación y coordinación de actividades de I.V.C. de alimentos para consumo humano.
            tr
              td Resolución 2674 de 2013
              td Deroga el Dec. 3075 de 2007 (Manipulación de alimentos).
            tr
              td Decreto 1686 de 2012 
              td Requisitos sanitarios para bebidas alcohólicas.
            tr
              td Circular 002 de 2018
              td Procuraduría – Informes bimensuales del PAE.
            tr
              td Comunicado 4150-0026-2021 
              td IVC en establecimientos gastronómicos que expendan carnes (solicitud de guías de sacrificio).

    Separador.mt-5        

    .cont_4_1.pt-3(style="position:relative;")
      .titulo-segundo.color-acento-contenido(style="position:relative")
        h2#t_4_1  4.2 Características de protocolos de manejo del riesgo

    p El protocolo para el manejo del riesgo sanitario se configura como una referencia que contiene un compendio de medidas de seguridad, y sirve de guía de buenas prácticas, de fácil comprensión para el sector comercial.

    p Su eficacia dependerá de la concienciación, responsabilidad y solidaridad, tanto de las empresas, de su personal y de los consumidores. El protocolo para el manejo del riesgo sanitario está estructurado básicamente en dos componentes: 

    .row.justify-content-center.my-5
      .col-lg-10 
      .row.justify-content-center 
        .col-1.mb-5.mb-sm-0
          img(src="@/assets/curso/temas/4/2.svg" ) 

        .col-7.mb-5.mb-sm-0
          ol.lista-ol--cuadro(style="border-radius: 20px; background-color: #D5FFF5") 
            li 
              .lista-ol--cuadro__vineta(style="border-radius: 10px;") 
                span a.
              b.mx-2 Uno general, en donde se encuentra todo el marco estratégico sobre el riesgo.
          ol.lista-ol--cuadro(style="border-radius: 20px; background-color: #D5FFF5") 
            li 
              .lista-ol--cuadro__vineta(style="border-radius: 10px;") 
                span b.
              b.mx-2 El programático, en donde están los objetivos, proyectos, responsabilidades de este.  

    .row.align-items-center.my-3.col-lg-12.mb-4           
      .col-7.p-0(style="background:#E7FFD1")
        p.py-2.px-5.m-0(style="background:#fff") El componente general supone objetivos estratégicos de manera global, es decir, tanto de los entes reguladores de sanidad como de las comunidades implicadas, de igual manera, se establece la ruta estratégica para alcanzar los objetivos propuestos.           
        p.py-3.px-5.m-0(style="background:#fff") Su eficacia dependerá de la concienciación, responsabilidad y solidaridad, tanto de las empresas, de su personal y de los consumidores. El protocolo para el manejo del riesgo sanitario está estructurado básicamente en dos componentes:         
        p.my-2.px-5(style="overflow-x: hidden !important") El documento de protocolos de manejo del riesgo debe tener elementos importantes como:

        .col-sm.mb-5.mb-sm-0.px-5
          ul.lista-ul--color
            li 
              i.fas.fa-check
              | Responsabilidades, principios y definiciones.
            li 
              i.fas.fa-check
              | Estructura: organización y dirección.
            li 
              i.fas.fa-check
              | Instrumentos de planificación.
            li 
              i.fas.fa-check
              | Financiación.
            li 
              i.fas.fa-check
              | Disposiciones finales.
      .col-5
        figure
          img(src='@/assets/curso/temas/4/3.png').m-auto(data-aos="fade-right") 
    
    Separador.mt-5        

    .cont_4_3.pt-3(style="position:relative;")
      .titulo-segundo.color-acento-contenido(style="position:relative")
        h2#t_4_3 4.3 Tipos de procedimiento de intervención sanitaria    

    p La intervención sanitaria son las acciones que se hacen para erradicar, eliminar, reducir niveles microbianos, controlar la transmisión natural de algún germen o prevenir la aparición de enfermedades que pueden ser dañinas para la comunidad en general, también existe un conjunto de medidas que garantizan una prevención óptima dependiendo de cada composición, estas tienen diferente tipo de potencia y alcance, así:     

    .row.justify-content-center.my-5(data-aos="fade-right")
      .col-lg-10 
        .titulo-sexto.mb-0.color-acento-contenido.mb-4
          p.mb-0 #[b Figura 7.] 
            i   Medidas de prevención      
        .row 
          figure.desktop.d-none.d-sm-block.d-sm-none.d-lg-block.d-none.d-md-block
            img.mb-1(src='@/assets/curso/temas/4/4.svg' alt='En la figuro 7 se muestran las medidas de prevención.').m-auto(data-aos="fade-right")
          figure.movil.mt-0
            .row.justify-content-center.d-lg-none.d-md-none        
              img(src="@/assets/curso/temas/4/5.svg" data-aos="zoom-in-up")   

    p Gracias a estos procedimientos se garantiza una protección no solo individual, sino colectiva, ya que nos ayudan a desarrollar buenos hábitos o actitudes sobre condiciones sanitarias, a todas estas intervenciones se les puede aplicar una mejora continua para generar así un mejor impacto en los conocimientos existentes respecto a lo sanitario.

    
    Separador.mt-5        

    .cont_4_4.pt-3(style="position:relative;")
      .titulo-segundo.color-acento-contenido(style="position:relative")
        h2#t_4_4 4.4 Características de manuales y guías de inspección sanitaria  

    p Las características más comunes en los manuales y guías de inspección sanitaria se realizan por medio de una ejecución ordenada en sus diferentes etapas, las cuales son:


    .row.align-items-center.my-3.col-lg-12.mb-4 
      .col-5
        figure
          img(src='@/assets/curso/temas/4/6.png').m-auto(data-aos="fade-right")            
      .col-7.p-4(style="background:#E7FFD1")
        p.mb-2(style="overflow-x: hidden !important") 1. Primero se debe determinar la frecuencia de inspección del establecimiento. 
        p.mb-2(style="overflow-x: hidden !important") 2. Una vez se sepa cuál es la frecuencia, se debe preparar la inspección para saber que se irá a hacer. 
        p.mb-2(style="overflow-x: hidden !important") 3. Al llegar al establecimiento se realiza la inspección in situ.
        p.mb-2(style="overflow-x: hidden !important") 4. Luego de esto, se evalúa y emite el concepto sanitario por parte de las autoridades que realizaron la revisión.  
        p.mb-2(style="overflow-x: hidden !important") 5. Seguido a esto se notifica y firma el acta que se diligenció. 
        p.mb-2(style="overflow-x: hidden !important") 6. Y, por último, se realiza el informe de inspección para emitir el concepto sanitario encontrado.
 
    p Al momento de la realización de una inspección sanitaria, se evalúan diferentes aspectos de higiene que van en pro a la protección de diferentes enfermedades, estos se clasifican en tres grupos, los cuales juntos ayudan a disminuir o prevenir este impacto sanitario:

    .row.justify-content-center.my-5(data-aos="fade-right")
      .col-lg-10 
        .titulo-sexto.mb-0.color-acento-contenido.mb-4
          p.mb-0 #[b Figura 8.] 
            i   Aspectos de higiene      
        .row 
          figure.desktop.d-none.d-sm-block.d-sm-none.d-lg-block.d-none.d-md-block
            img.mb-1(src='@/assets/curso/temas/4/7.svg' alt='En la figura 8 se muestran los tres grupos establecidos en los aspectos de higiene.').m-auto(data-aos="fade-right")
          figure.movil.mt-0
            .row.justify-content-center.d-lg-none.d-md-none        
              img(src="@/assets/curso/temas/4/8.svg" data-aos="zoom-in-up")   



      







</template>

<script>
export default {
  name: 'Tema4',
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass"></style>
